﻿namespace ClassLibraryLab8
{
    public class Class1
    {

    }
}
