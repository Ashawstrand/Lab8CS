﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryLab8
{
    public class Node
    {
        //Holds the data in a string
        public string Data;

        //Holds the reference to the next node in the linked list
        public Node Next;

        //Constructor to initialize the node with data
        public Node(string data)
        {
            Data = data;
            //Next is set to null by default
            Next = null;
        }
    }
}
