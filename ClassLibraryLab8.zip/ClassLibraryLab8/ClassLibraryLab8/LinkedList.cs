﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibraryLab8
{
        public class LinkedList
        {
            //properties set to private set, can only be set with class methods
            public int Count { get; private set; }
            public Node Head { get; private set; }

            //Adds a new item to the START of the linked list
            public void AddFirst(string value)
            {
                //create a new node
                Node newNode = new Node(value);
                // sets up connection where head would be the next node (sets up the chain for other links)
                newNode.Next = Head;
                // Update head to be the new node
                Head = newNode;
                // Increment the count of nodes in the list
                Count++;
            }

            // Adds a new item to the END of the linked list
            public void AddLast(string value)
            {
                // Create a new node with the given value
                Node newNode = new Node(value);

                // If the list is empty, set the head to the new node (very first item)
                if (Head == null)
                {
                    Head = newNode;
                }
                else
                // If the list is not empty, find the end of the list and add the new node
                {
                    //Start at the first node (head)
                    Node current = Head;

                    //loop to the end of the list
                    while (current.Next != null)
                    {
                        current = current.Next;
                    }
                    //Attach new node to the end of the list
                    current.Next = newNode;
                }
                // Increment the count of nodes in the list
                Count++;
            }

            // Removes the first item from the linked list
            public void RemoveFirst()
            {
                // Check if the head (list) is not empty
                if (Head != null)
                {
                    // Set the head to the next node, making head no longer referenced
                    Head = Head.Next;
                    // Decrement the count of nodes in the list
                    Count--;
                }
            }

            // Removes the last item from the linked list
            public void RemoveLast()
            {
                if (Head == null)
                {
                    // If the list is empty, do nothing
                    return;
                }

                else if (Head.Next == null)
                {
                    // If there's only one node, set head to null/clear the list
                    Head = null;
                    // Decrement the updated count of nodes in the list
                    Count--;
                    // Exit the method
                    return;
                }
                // If there are multiple nodes, go to the second last node
                else
                {
                    // Start at the head of the list
                    Node current = Head;
                    // Loop until the current node's next node is the last one
                    while (current.Next.Next != null)
                    {
                        // Move to the next node
                        current = current.Next;
                    }
                    //Remove the last node
                    current.Next = null;
                }
                // Decrement the count of nodes in the list
                Count--;
            }

            // Gets the value of the node at the specified index
            public string GetValue(int index)
            {
                // Check if the index is valid
                if (index < 0 || index >= Count)
                {
                    //throw an exception if the index is out of range
                    throw new ArgumentOutOfRangeException(nameof(index),"Index is out of range.");
                }

                //start at the head of the list
                Node current = Head;

                // Loop through the list until we reach the specified index
                for (int i = 0; i < index; i++)
                {
                    // Move to the next node
                    current = current.Next;
                }
                // Return the data of the node at the specified index
                return current.Data;
            }
        }
    }
